#!/usr/bin/env python3
from __future__ import annotations

import concurrent.futures
import ipaddress
import socket
import time
import urllib.error
import urllib.parse
from collections import Counter
from typing import Any

from common import fetch_json, hostname_from_url, is_public_ipv4, is_service_hostname, registrable_domain, validate_hostname


INSTITUTIONAL_AMENITIES = {"university", "college", "school", "library", "hospital", "clinic"}
INSTITUTIONAL_OFFICES = {"government", "association", "ngo", "research", "educational_institution"}
INSTITUTIONAL_TOURISM = {"museum"}

SOURCE_LANE = {
    "incumbent": "incumbent",
    "seed": "seed",
    "wikidata_institutional": "institutional",
    "openalex_institutional": "institutional",
    "osm_institutional": "institutional",
    "osm_general": "general_regional",
    "shodan_affinity": "network_affinity",
    "ct": "passive_expansion",
}


def _source_error(source: str, exc: Exception) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        return f"{source}:HTTPError:{exc.code}"
    return f"{source}:{type(exc).__name__}"


def _fetch_json_one_retry(*args: Any, **kwargs: Any) -> Any:
    """Retry one transient source failure only; never turn QUICK into a retry loop."""
    for attempt in range(2):
        try:
            return fetch_json(*args, **kwargs)
        except Exception as exc:
            transient = isinstance(exc, (TimeoutError, socket.timeout, urllib.error.URLError))
            if isinstance(exc, urllib.error.HTTPError):
                transient = exc.code == 429 or 500 <= exc.code <= 599
            if attempt == 0 and transient:
                time.sleep(0.35)
                continue
            raise
    raise RuntimeError("unreachable")


def resolve_public_ipv4(hostname: str) -> list[str]:
    try:
        infos = socket.getaddrinfo(hostname, 443, socket.AF_INET, socket.SOCK_STREAM)
    except OSError:
        return []
    return sorted({info[4][0] for info in infos if is_public_ipv4(info[4][0])})


def add_record(
    records: dict[str, dict[str, Any]],
    hostname: str | None,
    source: str,
    organization: str | None = None,
    distance_km: float | None = None,
    *,
    lane: str | None = None,
    affinity_ip: str | None = None,
) -> None:
    if not hostname:
        return
    try:
        hostname = validate_hostname(hostname)
    except ValueError:
        return
    record = records.setdefault(
        hostname,
        {
            "hostname": hostname,
            "sources": [],
            "lanes": [],
            "organizations": [],
            "distance_km": None,
            "affinity_evidence_ips": [],
        },
    )
    if source not in record["sources"]:
        record["sources"].append(source)
    selected_lane = lane or SOURCE_LANE.get(source)
    if selected_lane and selected_lane not in record["lanes"]:
        record["lanes"].append(selected_lane)
    if organization and organization not in record["organizations"]:
        record["organizations"].append(str(organization)[:200])
    if affinity_ip and affinity_ip not in record["affinity_evidence_ips"]:
        record["affinity_evidence_ips"].append(affinity_ip)
    if distance_km is not None:
        old = record.get("distance_km")
        if old is None or distance_km < old:
            record["distance_km"] = round(distance_km, 2)


def wikidata_institutional_nearby(lat: float, lon: float, radius_km: int, limit: int = 500) -> tuple[list[tuple[str, str]], str | None]:
    query = f'''SELECT ?item ?itemLabel ?website WHERE {{
      SERVICE wikibase:around {{
        ?item wdt:P625 ?location .
        bd:serviceParam wikibase:center "Point({lon} {lat})"^^geo:wktLiteral .
        bd:serviceParam wikibase:radius "{radius_km}" .
      }}
      ?item wdt:P856 ?website .
      VALUES ?class {{ wd:Q3918 wd:Q875538 wd:Q33506 wd:Q7075 wd:Q15284 wd:Q163740 wd:Q43229 wd:Q327333 wd:Q7278 }}
      ?item wdt:P31/wdt:P279* ?class .
      SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
    }} LIMIT {limit}'''
    url = "https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"query": query, "format": "json"})
    try:
        data = _fetch_json_one_retry(url, timeout=15, max_bytes=2_000_000, headers={"Accept": "application/sparql-results+json"})
        out = []
        for row in data.get("results", {}).get("bindings", []):
            host = hostname_from_url(row.get("website", {}).get("value", ""))
            label = row.get("itemLabel", {}).get("value", "")
            if host:
                out.append((host, label))
        return out, None
    except Exception as exc:
        return [], _source_error("wikidata", exc)


def _osm_lane(tags: dict[str, Any]) -> str:
    amenity = str(tags.get("amenity") or "").lower()
    office = str(tags.get("office") or "").lower()
    tourism = str(tags.get("tourism") or "").lower()
    if amenity in INSTITUTIONAL_AMENITIES or office in INSTITUTIONAL_OFFICES or tourism in INSTITUTIONAL_TOURISM:
        return "institutional"
    return "general_regional"


def osm_general_nearby(lat: float, lon: float, radius_km: int, limit: int = 1100) -> tuple[list[tuple[str, str, str]], str | None]:
    """Discover any nearby OSM feature that explicitly publishes an official website.

    This is intentionally broader than the institutional preference lane. The lane
    tag is derived from the feature type only for prioritization/reporting; it is
    never an eligibility rule.
    """
    radius_m = min(radius_km * 1000, 150_000)
    cap = max(100, min(int(limit), 1600))
    q = f'''[out:json][timeout:22];(
      nwr(around:{radius_m},{lat},{lon})[website];
      nwr(around:{radius_m},{lat},{lon})["contact:website"];
      nwr(around:{radius_m},{lat},{lon})["operator:website"];
    );out tags center {cap};'''
    try:
        body = urllib.parse.urlencode({"data": q}).encode()
        data = _fetch_json_one_retry(
            "https://overpass-api.de/api/interpreter",
            timeout=28,
            max_bytes=4_000_000,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=body,
        )
        out: list[tuple[str, str, str]] = []
        for item in data.get("elements", []):
            tags = item.get("tags", {}) if isinstance(item.get("tags"), dict) else {}
            website = tags.get("website") or tags.get("contact:website") or tags.get("operator:website")
            host = hostname_from_url(website or "")
            label = tags.get("name") or tags.get("operator") or tags.get("brand") or ""
            if host:
                out.append((host, label, _osm_lane(tags)))
        return out, None
    except Exception as exc:
        return [], _source_error("osm", exc)


def openalex_city(city: str, limit: int = 100) -> tuple[list[tuple[str, str]], str | None]:
    if not city:
        return [], None
    url = "https://api.openalex.org/institutions?" + urllib.parse.urlencode({"search": city, "per-page": min(limit, 100)})
    try:
        data = _fetch_json_one_retry(url, timeout=12, max_bytes=2_000_000)
        out = []
        for item in data.get("results", []):
            host = hostname_from_url(item.get("homepage_url") or "")
            if host:
                out.append((host, item.get("display_name") or ""))
        return out, None
    except Exception as exc:
        return [], _source_error("openalex", exc)


def ripe_network_info(ip: str) -> tuple[dict[str, Any] | None, str | None]:
    url = "https://stat.ripe.net/data/network-info/data.json?" + urllib.parse.urlencode({"resource": ip})
    try:
        data = _fetch_json_one_retry(url, timeout=10, max_bytes=500_000)
        payload = data.get("data") if isinstance(data, dict) else None
        if not isinstance(payload, dict):
            return None, None
        asns = payload.get("asns") or []
        asn = asns[0] if asns else None
        prefix = payload.get("prefix")
        return {"asn": asn, "prefix": prefix}, None
    except Exception as exc:
        return None, _source_error("ripestat_network_info", exc)


def ripe_announced_prefixes(asn: Any, limit: int = 8) -> tuple[list[str], str | None]:
    if not asn:
        return [], None
    resource = str(asn)
    if not resource.upper().startswith("AS"):
        resource = "AS" + resource
    url = "https://stat.ripe.net/data/announced-prefixes/data.json?" + urllib.parse.urlencode({"resource": resource})
    try:
        data = _fetch_json_one_retry(url, timeout=12, max_bytes=1_500_000)
        payload = data.get("data") if isinstance(data, dict) else None
        rows = payload.get("prefixes") if isinstance(payload, dict) else []
        prefixes: list[str] = []
        for item in rows or []:
            raw = item.get("prefix") if isinstance(item, dict) else None
            if not raw:
                continue
            try:
                network = ipaddress.ip_network(str(raw), strict=False)
            except ValueError:
                continue
            if isinstance(network, ipaddress.IPv4Network):
                prefixes.append(str(network))
        prefixes.sort(key=lambda value: (ipaddress.ip_network(value).prefixlen * -1, value))
        return prefixes[: max(1, int(limit))], None
    except Exception as exc:
        return [], _source_error("ripestat_announced_prefixes", exc)


def _usable_ip(network: ipaddress.IPv4Network, value: int) -> str | None:
    try:
        addr = ipaddress.IPv4Address(value)
    except ipaddress.AddressValueError:
        return None
    if addr not in network or addr == network.network_address or addr == network.broadcast_address or not addr.is_global:
        return None
    return str(addr)


def sample_affinity_ips(target_ip: str, target_prefix: str | None, prefixes: list[str], cap: int) -> list[str]:
    """Select a tiny deterministic passive-lookup sample; never actively scan a prefix."""
    cap = max(1, int(cap))
    try:
        target_addr = ipaddress.ip_address(target_ip)
    except ValueError:
        return []
    if not isinstance(target_addr, ipaddress.IPv4Address):
        return []

    networks: list[ipaddress.IPv4Network] = []
    for raw in [target_prefix, *prefixes]:
        if not raw:
            continue
        try:
            net = ipaddress.ip_network(str(raw), strict=False)
        except ValueError:
            continue
        if isinstance(net, ipaddress.IPv4Network) and net not in networks:
            networks.append(net)
    if not networks:
        networks = [ipaddress.ip_network(f"{target_addr}/24", strict=False)]

    chosen: list[str] = []
    seen: set[str] = {str(target_addr)}
    for idx, network in enumerate(networks):
        if len(chosen) >= cap:
            break
        # Spend most of the budget around the exact target prefix, then take a
        # few deterministic representatives from other prefixes announced by
        # the same ASN. These are Shodan/InternetDB lookups, not TCP probes.
        target_budget = min(cap - len(chosen), 14 if idx == 0 else 4)
        base = int(network.network_address)
        last = int(network.broadcast_address)
        candidates = []
        if target_addr in network:
            t = int(target_addr)
            candidates.extend(t + delta for delta in (-32, -16, -8, -4, -2, -1, 1, 2, 4, 8, 16, 32))
        span = max(1, last - base)
        candidates.extend(
            base + int(span * fraction)
            for fraction in (0.01, 0.05, 0.125, 0.25, 0.5, 0.75, 0.875, 0.95, 0.99)
        )
        used_here = 0
        for value in candidates:
            ip = _usable_ip(network, value)
            if not ip or ip in seen:
                continue
            seen.add(ip)
            chosen.append(ip)
            used_here += 1
            if used_here >= target_budget or len(chosen) >= cap:
                break
    return chosen[:cap]


def shodan_internetdb_ip(ip: str) -> tuple[list[str], str | None]:
    try:
        data = _fetch_json_one_retry(f"https://internetdb.shodan.io/{urllib.parse.quote(ip, safe='')}", timeout=8, max_bytes=500_000)
        hosts: list[str] = []
        for raw in (data.get("hostnames") or []) if isinstance(data, dict) else []:
            try:
                host = validate_hostname(str(raw))
            except ValueError:
                continue
            if host not in hosts:
                hosts.append(host)
        return hosts, None
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return [], None
        return [], _source_error("shodan_internetdb", exc)
    except Exception as exc:
        return [], _source_error("shodan_internetdb", exc)


def discover_network_affinity(job: dict[str, Any], preflight: dict[str, Any]) -> dict[str, Any]:
    limits = job["limits"]
    target_ip = str((job.get("target") or {}).get("inventory_ipv4") or preflight.get("observed_egress_ip") or "")
    info, info_err = ripe_network_info(target_ip)
    errors: list[str] = [info_err] if info_err else []
    asn = (info or {}).get("asn")
    prefix = (info or {}).get("prefix")
    prefixes, prefix_err = ripe_announced_prefixes(asn, int(limits.get("affinity_prefix_cap", 4)))
    if prefix_err:
        errors.append(prefix_err)
    sampled = sample_affinity_ips(target_ip, prefix, prefixes, int(limits.get("affinity_passive_ip_cap", 24)))
    host_rows: list[tuple[str, str]] = []
    if sampled:
        workers = min(8, len(sampled))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(shodan_internetdb_ip, ip): ip for ip in sampled}
            for future in concurrent.futures.as_completed(future_map):
                ip = future_map[future]
                try:
                    hosts, err = future.result()
                except Exception as exc:
                    hosts, err = [], f"shodan_internetdb:{type(exc).__name__}"
                if err:
                    errors.append(err)
                for host in hosts:
                    host_rows.append((host, ip))
    dedup: dict[str, str] = {}
    for host, ip in host_rows:
        dedup.setdefault(host, ip)
    return {
        "target_ip": target_ip or None,
        "target_asn": asn,
        "target_prefix": prefix,
        "announced_prefixes_considered": prefixes,
        "sampled_passive_ips": sampled,
        "hostnames": [{"hostname": host, "evidence_ip": ip} for host, ip in sorted(dedup.items())],
        "errors": sorted(set(errors)),
        "method": "RIPESTAT_BGP_PLUS_SHODAN_INTERNETDB_PASSIVE_SAMPLE",
        "active_scan": False,
    }


def ct_names(base: str, max_names: int) -> tuple[list[str], str | None]:
    url = "https://crt.sh/?" + urllib.parse.urlencode({"q": f"%.{base}", "output": "json"})
    try:
        data = _fetch_json_one_retry(url, timeout=12, max_bytes=3_000_000)
        names: list[str] = []
        seen = set()
        for item in data if isinstance(data, list) else []:
            for raw in str(item.get("name_value", "")).splitlines():
                raw = raw.strip().lstrip("*.")
                try:
                    host = validate_hostname(raw)
                except ValueError:
                    continue
                if not host.endswith("." + base) and host != base:
                    continue
                if host not in seen:
                    seen.add(host)
                    names.append(host)
                    if len(names) >= max_names:
                        return names, None
        return names, None
    except Exception as exc:
        return [], _source_error("ct", exc)


def _record_lane_priority(record: dict[str, Any]) -> int:
    lanes = set(record.get("lanes") or [])
    for idx, lane in enumerate(("network_affinity", "general_regional", "institutional", "seed", "passive_expansion")):
        if lane in lanes:
            return idx
    return 9


def _count_labels(rows: list[dict[str, Any]], key: str) -> dict[str, int]:
    counter: Counter[str] = Counter()
    for row in rows:
        for value in row.get(key) or []:
            counter[str(value)] += 1
    return dict(sorted(counter.items()))


def discover(job: dict[str, Any], preflight: dict[str, Any]) -> dict[str, Any]:
    limits = job["limits"]
    profile = job["profile"]
    quick = profile.get("run_mode") == "quick"
    stop_target = int(profile.get("source_stop_target", limits["source_pool_cap"]))
    records: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    incumbent = job["incumbent"]

    for host in job.get("seed_domains", []):
        add_record(records, host, "seed")
    add_record(records, incumbent, "incumbent")

    loc = preflight.get("location") or {}
    lat, lon = loc.get("latitude"), loc.get("longitude")
    city = str(loc.get("city") or "")
    region_mismatch = bool(preflight.get("region_mismatch"))

    affinity = discover_network_affinity(job, preflight)
    errors.extend(affinity.get("errors") or [])
    affinity_org = f"AS{affinity.get('target_asn')}" if affinity.get("target_asn") else None
    for item in affinity.get("hostnames") or []:
        add_record(
            records,
            item.get("hostname"),
            "shodan_affinity",
            affinity_org,
            lane="network_affinity",
            affinity_ip=item.get("evidence_ip"),
        )

    def collect_regional(radius: int, include_openalex: bool) -> None:
        jobs: list[tuple[str, Any]] = [
            ("osm", lambda: osm_general_nearby(float(lat), float(lon), radius, int(limits.get("general_osm_record_cap", 1100)))),
            ("wikidata", lambda: wikidata_institutional_nearby(float(lat), float(lon), radius)),
        ]
        if include_openalex and city:
            jobs.append(("openalex", lambda: openalex_city(city)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(jobs)) as executor:
            future_map = {executor.submit(fn): source for source, fn in jobs}
            for future in concurrent.futures.as_completed(future_map):
                source = future_map[future]
                try:
                    items, err = future.result()
                except Exception as exc:
                    items, err = [], f"{source}:{type(exc).__name__}"
                if err:
                    errors.append(err)
                if source == "osm":
                    for host, org, lane in items:
                        add_record(records, host, "osm_institutional" if lane == "institutional" else "osm_general", org, lane=lane)
                elif source == "wikidata":
                    for host, org in items:
                        add_record(records, host, "wikidata_institutional", org, lane="institutional")
                else:
                    for host, org in items:
                        add_record(records, host, "openalex_institutional", org, lane="institutional")

    expanded_regional_performed = False
    if isinstance(lat, (int, float)) and isinstance(lon, (int, float)) and not region_mismatch:
        primary = int(profile["primary_radius_km"])
        expanded = int(profile["expanded_radius_km"])
        collect_regional(primary, include_openalex=True)
        if not quick or len(records) < stop_target:
            collect_regional(expanded, include_openalex=False)
            expanded_regional_performed = True
    else:
        errors.append("LOCATION_DEGRADED" if not region_mismatch else "REGION_MISMATCH_REVIEW")
        if city and not region_mismatch:
            items, err = openalex_city(city)
            if err:
                errors.append(err)
            for host, org in items:
                add_record(records, host, "openalex_institutional", org, lane="institutional")

    # CT is cross-lane passive expansion. It is no longer restricted to
    # institutional roots; affinity/general/seed roots may all contribute.
    ct_skipped_sufficient = quick and len(records) >= stop_target
    ct_bases_queried: list[str] = []
    if not ct_skipped_sufficient:
        bases: list[tuple[str, str | None, str | None]] = []
        seen_bases: set[str] = set()
        ordered_parents = sorted(records.values(), key=lambda row: (_record_lane_priority(row), row["hostname"]))
        for rec in ordered_parents:
            if rec["hostname"] == incumbent:
                continue
            try:
                base = registrable_domain(rec["hostname"])
            except ValueError:
                continue
            if base in seen_bases:
                continue
            seen_bases.add(base)
            parent_lane = next((lane for lane in ("network_affinity", "general_regional", "institutional", "seed") if lane in set(rec.get("lanes") or [])), None)
            org = (rec.get("organizations") or [None])[0]
            bases.append((base, parent_lane, org))
            if len(bases) >= int(limits.get("ct_base_cap", 40)):
                break
        consecutive_failures = 0
        ct_stopped = False
        for base, parent_lane, org in bases:
            if consecutive_failures >= int(profile["ct_failure_budget"]):
                ct_stopped = True
                break
            ct_bases_queried.append(base)
            names, err = ct_names(base, int(limits.get("ct_max_per_domain", 20)))
            if err:
                consecutive_failures += 1
                errors.append(err)
                continue
            consecutive_failures = 0
            for host in names:
                add_record(records, host, "ct", org, lane=parent_lane or "passive_expansion")
                if parent_lane:
                    rec = records.get(host)
                    if rec is not None and "passive_expansion" not in rec["lanes"]:
                        rec["lanes"].append("passive_expansion")
            if len(records) >= int(limits["source_pool_cap"]):
                break
            if quick and len(records) >= stop_target:
                break
        if ct_stopped:
            errors.append("CT_SKIPPED_AFTER_FAILURE_BUDGET")

    priority = {
        "incumbent": 0,
        "seed": 1,
        "shodan_affinity": 2,
        "osm_general": 3,
        "osm_institutional": 4,
        "wikidata_institutional": 4,
        "openalex_institutional": 5,
        "ct": 6,
    }
    ordered = sorted(
        records.values(),
        key=lambda r: (
            0 if r["hostname"] == incumbent else 1,
            _record_lane_priority(r),
            min(priority.get(s, 9) for s in r["sources"]),
            r["hostname"],
        ),
    )
    ordered = ordered[: int(limits["source_pool_cap"])]

    incumbent_set = {incumbent}
    to_validate = [r for r in ordered if not is_service_hostname(r["hostname"]) or r["hostname"] in incumbent_set]
    validated: list[dict[str, Any]] = []
    workers = min(16, max(1, int(limits.get("dns_workers", 12))))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {executor.submit(resolve_public_ipv4, r["hostname"]): r for r in to_validate}
        for future in concurrent.futures.as_completed(future_map):
            rec = future_map[future]
            try:
                ips = future.result()
            except Exception:
                ips = []
            if ips:
                item = dict(rec)
                item["initial_ipv4"] = ips
                validated.append(item)
    validated.sort(
        key=lambda r: (
            0 if r["hostname"] == incumbent else 1,
            _record_lane_priority(r),
            min(priority.get(s, 9) for s in r["sources"]),
            r["hostname"],
        )
    )
    validated = validated[: int(limits["discovered_cap"])]
    count = len(validated)
    goal = int(profile["coverage_goal"])
    coverage = "GOOD" if count >= goal else "LIMITED" if count >= min(100, goal) else "SPARSE"
    lane_counts = _count_labels(validated, "lanes")
    source_counts = _count_labels(validated, "sources")
    active_discovery_lanes = [lane for lane in ("general_regional", "institutional", "network_affinity") if lane_counts.get(lane, 0) > 0]
    return {
        "source_records": ordered,
        "validated": validated,
        "coverage": coverage,
        "errors": sorted(set(errors)),
        "ct_skipped_sufficient_sources": ct_skipped_sufficient,
        "affinity_search": affinity,
        "lane_counts": lane_counts,
        "source_counts": source_counts,
        "active_discovery_lanes": active_discovery_lanes,
        "expanded_regional_performed": expanded_regional_performed,
        "ct_bases_queried": ct_bases_queried,
        "counts": {
            "source_records": len(ordered),
            "validated_ipv4": count,
            "active_discovery_lanes": len(active_discovery_lanes),
        },
    }


def _restore_record(records: dict[str, dict[str, Any]], row: dict[str, Any]) -> None:
    host = row.get("hostname")
    if not host:
        return
    for source in row.get("sources") or ["ct"]:
        lane = None
        for candidate_lane in row.get("lanes") or []:
            if candidate_lane != "passive_expansion":
                lane = candidate_lane
                break
        add_record(records, host, str(source), (row.get("organizations") or [None])[0], row.get("distance_km"), lane=lane)
    for lane in row.get("lanes") or []:
        rec = records.get(host)
        if rec is not None and lane not in rec["lanes"]:
            rec["lanes"].append(lane)
    for ip in row.get("affinity_evidence_ips") or []:
        rec = records.get(host)
        if rec is not None and ip not in rec["affinity_evidence_ips"]:
            rec["affinity_evidence_ips"].append(ip)


def discover_extension(job: dict[str, Any], preflight: dict[str, Any], prior: dict[str, Any]) -> dict[str, Any]:
    """Quality-driven second discovery pass used only when Gate yield is low.

    It expands sources without repeating candidate TCP/TLS tests: broaden the
    regional radius only if the initial run skipped it, then spend a separate
    bounded CT budget on roots that were not queried before.
    """
    limits = job["limits"]
    profile = job["profile"]
    records: dict[str, dict[str, Any]] = {}
    for row in prior.get("source_records") or []:
        _restore_record(records, row)
    previous_hosts = set(records)
    errors: list[str] = []

    loc = preflight.get("location") or {}
    lat, lon = loc.get("latitude"), loc.get("longitude")
    region_mismatch = bool(preflight.get("region_mismatch"))
    regional_added = False
    if not prior.get("expanded_regional_performed") and isinstance(lat, (int, float)) and isinstance(lon, (int, float)) and not region_mismatch:
        radius = int(profile["expanded_radius_km"])
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = {
                executor.submit(osm_general_nearby, float(lat), float(lon), radius, int(limits.get("general_osm_record_cap", 1100))): "osm",
                executor.submit(wikidata_institutional_nearby, float(lat), float(lon), radius): "wikidata",
            }
            for future in concurrent.futures.as_completed(futures):
                source = futures[future]
                try:
                    items, err = future.result()
                except Exception as exc:
                    items, err = [], f"{source}:{type(exc).__name__}"
                if err:
                    errors.append(err)
                if source == "osm":
                    for host, org, lane in items:
                        before = host in records
                        add_record(records, host, "osm_institutional" if lane == "institutional" else "osm_general", org, lane=lane)
                        regional_added = regional_added or not before
                else:
                    for host, org in items:
                        before = host in records
                        add_record(records, host, "wikidata_institutional", org, lane="institutional")
                        regional_added = regional_added or not before

    already_ct = set(prior.get("ct_bases_queried") or [])
    base_rows: list[tuple[str, str | None, str | None]] = []
    seen_bases = set(already_ct)
    for rec in sorted(records.values(), key=lambda row: (_record_lane_priority(row), row["hostname"])):
        if rec.get("hostname") == job.get("incumbent"):
            continue
        try:
            base = registrable_domain(rec["hostname"])
        except ValueError:
            continue
        if base in seen_bases:
            continue
        seen_bases.add(base)
        parent_lane = next((lane for lane in ("network_affinity", "general_regional", "institutional", "seed") if lane in set(rec.get("lanes") or [])), None)
        org = (rec.get("organizations") or [None])[0]
        base_rows.append((base, parent_lane, org))
        if len(base_rows) >= int(limits.get("ct_extension_base_cap", 16)):
            break

    extension_ct_bases: list[str] = []
    consecutive_failures = 0
    for base, parent_lane, org in base_rows:
        if consecutive_failures >= int(profile["ct_failure_budget"]):
            errors.append("CT_EXTENSION_SKIPPED_AFTER_FAILURE_BUDGET")
            break
        extension_ct_bases.append(base)
        names, err = ct_names(base, int(limits.get("ct_max_per_domain", 20)))
        if err:
            errors.append(err)
            consecutive_failures += 1
            continue
        consecutive_failures = 0
        for host in names:
            add_record(records, host, "ct", org, lane=parent_lane or "passive_expansion")
            rec = records.get(host)
            if rec is not None and "passive_expansion" not in rec["lanes"]:
                rec["lanes"].append("passive_expansion")

    new_records = [row for host, row in records.items() if host not in previous_hosts]
    priority = {
        "seed": 1, "shodan_affinity": 2, "osm_general": 3, "osm_institutional": 4,
        "wikidata_institutional": 4, "openalex_institutional": 5, "ct": 6,
    }
    new_records.sort(key=lambda r: (_record_lane_priority(r), min(priority.get(src, 9) for src in r.get("sources") or []), r["hostname"]))
    new_records = new_records[: int(limits.get("discovery_extension_cap", 80))]
    to_validate = [r for r in new_records if not is_service_hostname(r["hostname"])]
    validated: list[dict[str, Any]] = []
    workers = min(16, max(1, int(limits.get("dns_workers", 12))))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {executor.submit(resolve_public_ipv4, r["hostname"]): r for r in to_validate}
        for future in concurrent.futures.as_completed(future_map):
            rec = future_map[future]
            try:
                ips = future.result()
            except Exception:
                ips = []
            if ips:
                item = dict(rec)
                item["initial_ipv4"] = ips
                validated.append(item)
    validated.sort(key=lambda r: (_record_lane_priority(r), min(priority.get(src, 9) for src in r.get("sources") or []), r["hostname"]))
    return {
        "validated": validated,
        "new_source_records": new_records,
        "errors": sorted(set(errors)),
        "expanded_regional_performed": regional_added or bool(prior.get("expanded_regional_performed")),
        "ct_bases_queried": extension_ct_bases,
        "counts": {"new_source_records": len(new_records), "validated_ipv4": len(validated)},
        "lane_counts": _count_labels(validated, "lanes"),
    }
